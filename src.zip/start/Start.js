const Start = () =>{
    <div style={{
        width: '100%',
        height:'100vh',
        color: '#202b4257',
        zIndex:'1'
    }}>
 
    </div>
}

export default Start;